
from load_test_data import *
from network import *
import vgg19_trainable as vgg19

test_num = 654 * 7
IMAGE_HEIGHT = 480
IMAGE_WIDTH = 640

dataset_path = "models/"
model_path = dataset_path + "model.ckpt"

def max_threshold(prediction, groundtruth):
    shape = np.shape(prediction)
    tmp_max = np.zeros([shape[0], shape[1]])
    for i in range(shape[0]):
        for j in range(shape[1]):
            var_pre = prediction[i, j] / groundtruth[i, j]
            var_gro = groundtruth[i, j] / prediction[i, j]
            if var_pre > var_gro:
                tmp_max[i,j] = var_pre
            else:
                tmp_max[i,j] = var_gro
    return tmp_max

def accuracy_with_threshold(max_value):
    t1 = 1.25
    t2 = 1.25**2
    t3 = 1.25**3
    deta1 = 0
    deta2 = 0
    deta3 = 0
    shape = np.shape(max_value)
    var1 = max_value < t1
    var2 = max_value < t2
    var3 = max_value < t3
    deta1 = np.mean(var1)
    deta2 = np.mean(var2)
    deta3 = np.mean(var3)
    return deta1, deta2, deta3

def main(argv=None):
    graph = tf.get_default_graph()
    with graph.as_default():

        # load data
        test_image, test_label, test_fl = input_pipeline()

        # Construct model
        # vgg_net = vgg.Vgg16()
        # vgg_net.build(test_image)
        # pool5 = vgg_net.conv5_3
        # pool4 = vgg_net.conv4_3
        # pool3 = vgg_net.conv3_3
        # pool2 = vgg_net.conv2_2
        # pool1 = vgg_net.conv1_2

        vgg_net = vgg19.Vgg19('./vgg19.npy')
        vgg_net.build(test_image)
        pool5 = vgg_net.conv5_4

        prediction_depth = my_cnn(pool5, test_label, test_image, test_fl)

        prediction_depth = tf.image.resize_images(prediction_depth, [IMAGE_HEIGHT, IMAGE_WIDTH])
        # Initializaing the variables
        init = tf.global_variables_initializer()

        # 'Saver' op to save and restore all the variables
        saver = tf.train.Saver()

        # error measures
        rel = np.array([0] * test_num, dtype=np.float64)
        rmse = np.array([0] * test_num, dtype=np.float64)
        log10_v = np.array([0] * test_num, dtype=np.float64)
        numel_vaild = np.array([0] * test_num, dtype=np.float64)
        max_value = np.zeros([480, 640, test_num])

        start_time = time.time()
        # Running session
        print "Starting session... "
        with tf.Session() as sess:

            # initialize the variables
            sess.run(init)

            # initialize the queue threads to start to shovel data
            coord = tf.train.Coordinator()
            threads = tf.train.start_queue_runners(coord=coord)

            # Restore model weights from previously saved model
            load_path = saver.restore(sess, model_path)
            print "Model restored from file: %s" % model_path

            print "from the train set:"
            for i in range(test_num):
                pre_depth, test_image_aug1, test_label_aug1 = sess.run([prediction_depth, test_image, test_label])

                test_image_aug1 = np.squeeze(test_image_aug1)
                test_label_aug1 = np.squeeze(test_label_aug1)
                pre_depth = np.squeeze(pre_depth)
                #            test_image_aug1[:, :, [2, 1, 0]] = test_image_aug1[:, :, [0, 1, 2]]

                test_image_aug1 = np.squeeze(test_image_aug1)
                test_label_aug1 = np.squeeze(test_label_aug1)
                pre_depth = np.squeeze(pre_depth)
                #            test_image_aug1[:, :, [2, 1, 0]] = test_image_aug1[:, :, [0, 1, 2]]

                # Error measures
                groundtruth = test_label_aug1
                prediction = pre_depth

                max_value[..., i] = max_threshold(prediction, groundtruth)
                # print max_percent[..., i]

                # Vaild pixels mask
                mask = (groundtruth > 0) & (groundtruth < 10)
                num_vaild = np.sum(mask)
                numel_vaild[i] = num_vaild
                depth_error = np.fabs(prediction - groundtruth)

                # relative error
                rel_error = depth_error / groundtruth
                rel_error[~mask] = 0
                rel_value = np.sum(rel_error)
                # rel_mean = rel_value / num_vaild
                rel[i] = rel_value

                # rmse
                rms_error = np.power(depth_error, 2)
                rms_error[~mask] = 0
                # rms_mean = np.sqrt(np.sum(rms_error) / num_vaild)
                # rms_mean = np.sum(rms_error) / num_vaild
                rmse[i] = np.sum(rms_error)

                # log10
                groundtruth[groundtruth == 0] = 1e-6
                prediction[prediction == 0] = 1e-6
                y1 = np.log10(groundtruth)
                y2 = np.log10(prediction)
                log_error = np.fabs(y1 - y2)
                log_error[~mask] = 0
                # log_mean = np.sum(log_error) / num_vaild
                log10_v[i] = np.sum(log_error)
                print log10_v[i]

                if i % 1 == 0:
                    print('Testing image %d' % i)

#                    win_image = cv2.namedWindow('input_image', 0)
#                    win_depth = cv2.namedWindow('input_depth', 0)
#                    win_pre_depth = cv2.namedWindow('pre_depth', 0)
#
#                    cv2.imshow('input_image', test_image_aug1 / 255)
#                    cv2.imshow('input_depth', test_label_aug1 / 5)
#                    cv2.imshow('pre_depth', pre_depth / 5)
#
#                    file = 'test_results/' + str(i + 1) + '.png'
#
#                    pre_depth = pre_depth / np.max(pre_depth)
#                    pre_depth = pre_depth * 2 ** 16
#                    pre_depth = pre_depth.astype('uint16')
#
#                    cv2.imwrite(file, pre_depth)
#
#                    cv2.waitKey(1)
#                    cv2.destroyWindow('all')

            print "Testing Finished!"

            # echo prediction error measures
            number = np.sum(numel_vaild)
            rel_va = np.sum(rel)
            print "relative error is: %f" % np.divide(rel_va, number)

            rmse_va = np.sum(rmse)
            print "rmse is: %f" % np.sqrt(np.divide(rmse_va, number))

            log10_va = np.sum(log10_v)
            print "log10 error is: %f" % np.divide(log10_va, number)

            deta1, deta2, deta3 = accuracy_with_threshold(max_value)
            print "accuracy with threshold are: %f, %f, %f" % (deta1, deta2, deta3)

            # stop our queue threads and properly close the session
            coord.request_stop()
            coord.join(threads)
            sess.close()

            elapsed_time = time.time() - start_time
            print elapsed_time

if __name__ == '__main__':
    main()

