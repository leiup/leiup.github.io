import tensorflow as tf
import numpy as np
import tensorflow.contrib.layers as ly

# Define and initialize training parameters
std = 0.01
scale_normalization = 5

def variable_summaries(var):
  """Attach a lot of summaries to a Tensor (for TensorBoard visualization)."""
  with tf.name_scope('summaries'):
    mean = tf.reduce_mean(var)
    tf.summary.scalar('mean', mean)
    # with tf.name_scope('stddev'):
    #   stddev = tf.sqrt(tf.reduce_mean(tf.square(var - mean)))
    # tf.summary.scalar('stddev', stddev)
    # tf.summary.scalar('max', tf.reduce_max(var))
    # tf.summary.scalar('min', tf.reduce_min(var))
    tf.summary.histogram('histogram', var)

# define graph architecture
def my_cnn(pool5, pool4, pool3, pool2, pool1, label, image, train_fl):

    with tf.variable_scope('layer1'):

        pool5_size = pool5.get_shape().as_list()
        W_fc1 = tf.Variable(tf.random_normal(
            [pool5_size[1] * pool5_size[2] * pool5_size[3], 1024], stddev=std))
        b_fc1 = tf.Variable(tf.random_normal([1024], stddev=std))
        W_fc2 = tf.Variable(tf.random_normal(
            [1024+512, pool5_size[1] * pool5_size[2] * pool5_size[3]], stddev=std))
        b_fc2 = tf.Variable(tf.random_normal([pool5_size[1] * pool5_size[2] * pool5_size[3]], stddev=std))

        relu5_flat = tf.reshape(pool5, [-1, pool5_size[1] * pool5_size[2] * pool5_size[3]])
        fc1 = tf.nn.relu(tf.matmul(relu5_flat, W_fc1) + b_fc1)

        # focal length information
        train_fl = tf.stack([train_fl, train_fl, train_fl, train_fl, train_fl, train_fl, train_fl], 1)
        # train_fl = tf.to_float(train_fl, name='ToFloat')
        fl_1 = ly.fully_connected(train_fl, 64)
        fl_2 = ly.fully_connected(fl_1, 512)
        fc_fuse = tf.concat([fc1, fl_2], 1)

        fc2 = tf.nn.relu(tf.matmul(fc_fuse, W_fc2) + b_fc2)
        fc2_layer = tf.reshape(fc2, [-1, pool5_size[1], pool5_size[2], pool5_size[3]])

        # fully convolution
        fc2_layer_1 = ly.conv2d(fc2_layer,
                                num_outputs=1024, kernel_size=1, stride=1,
                                weights_initializer=tf.random_normal_initializer(0, 0.01))

        fc2_layer_2 = ly.conv2d(fc2_layer_1,
                                num_outputs=512, kernel_size=1, stride=1,
                                weights_initializer=tf.random_normal_initializer(0, 0.01))

        layer1_1 = ly.conv2d(fc2_layer_2,
                             num_outputs=256, kernel_size=3, stride=1,
                             weights_initializer=tf.random_normal_initializer(0, 0.01))

        layer1_2 = ly.conv2d(layer1_1,
                             num_outputs=256, kernel_size=3, stride=1,
                             weights_initializer=tf.random_normal_initializer(0, 0.01))

        layer1_3 = ly.conv2d(layer1_2,
                             num_outputs=256, kernel_size=3, stride=1,
                             weights_initializer=tf.random_normal_initializer(0, 0.01))

        # sub network#
        sub1_1_relu = ly.conv2d(pool5,
                                num_outputs=256, kernel_size=3, stride=1,
                                weights_initializer=tf.random_normal_initializer(0, 0.01))

        sub1_2_relu = ly.conv2d(sub1_1_relu,
                                num_outputs=512, kernel_size=3, stride=1,
                                weights_initializer=tf.random_normal_initializer(0, 0.01))

        layer1_end = tf.concat([layer1_3, sub1_2_relu], 3)

        print layer1_end.get_shape()

    with tf.variable_scope('layer2'):

        dec1_relu = ly.conv2d_transpose(layer1_end,
                                        num_outputs=768, kernel_size=3, stride=2,
                                        weights_initializer=tf.random_normal_initializer(0, 0.01))

        layer2_1 = ly.conv2d(dec1_relu,
                             num_outputs=512, kernel_size=3, stride=1,
                             weights_initializer=tf.random_normal_initializer(0, 0.01))

        layer2_2 = ly.conv2d(layer2_1,
                             num_outputs=256, kernel_size=3, stride=1,
                             weights_initializer=tf.random_normal_initializer(0, 0.01))

        layer2_3 = ly.conv2d(layer2_2,
                             num_outputs=256, kernel_size=3, stride=1,
                             weights_initializer=tf.random_normal_initializer(0, 0.01))

        sub2_1_relu = ly.conv2d(pool4,
                                num_outputs=256, kernel_size=3, stride=1,
                                weights_initializer=tf.random_normal_initializer(0, 0.01))

        sub2_2_relu = ly.conv2d(sub2_1_relu,
                                num_outputs=512, kernel_size=3, stride=1,
                                weights_initializer=tf.random_normal_initializer(0, 0.01))

        layer2_end = tf.concat([layer2_3, sub2_2_relu], 3)

        print layer2_end.get_shape()

    with tf.variable_scope('layer3'):

        dec2_relu = ly.conv2d_transpose(layer2_end,
                                        num_outputs=768, kernel_size=3, stride=2,
                                        weights_initializer=tf.random_normal_initializer(0, 0.01))

        layer3_1 = ly.conv2d(dec2_relu,
                             num_outputs=512, kernel_size=3, stride=1,
                             weights_initializer=tf.random_normal_initializer(0, 0.01))

        layer3_2 = ly.conv2d(layer3_1,
                             num_outputs=256, kernel_size=3, stride=1,
                             weights_initializer=tf.random_normal_initializer(0, 0.01))

        layer3_3 = ly.conv2d(layer3_2,
                             num_outputs=256, kernel_size=3, stride=1,
                             weights_initializer=tf.random_normal_initializer(0, 0.01))

        sub3_1_relu = ly.conv2d(pool3,
                                num_outputs=128, kernel_size=3, stride=1,
                                weights_initializer=tf.random_normal_initializer(0, 0.01))

        sub3_2_relu = ly.conv2d(sub3_1_relu,
                                num_outputs=256, kernel_size=3, stride=1,
                                weights_initializer=tf.random_normal_initializer(0, 0.01))

        layer3_end = tf.concat([layer3_3, sub3_2_relu], 3)

        print layer3_end.get_shape()

    with tf.variable_scope('layer4'):

        dec3_relu = ly.conv2d_transpose(layer3_end,
                                        num_outputs=512, kernel_size=5, stride=2,
                                        weights_initializer=tf.random_normal_initializer(0, 0.01))

        layer4_1 = ly.conv2d(dec3_relu,
                             num_outputs=256, kernel_size=3, stride=1,
                             weights_initializer=tf.random_normal_initializer(0, 0.01))

        layer4_2 = ly.conv2d(layer4_1,
                             num_outputs=128, kernel_size=3, stride=1,
                             weights_initializer=tf.random_normal_initializer(0, 0.01))

        sub4_1_relu = ly.conv2d(pool2,
                                num_outputs=64, kernel_size=5, stride=1,
                                weights_initializer=tf.random_normal_initializer(0, 0.01))

        sub4_2_relu = ly.conv2d(sub4_1_relu,
                                num_outputs=128, kernel_size=5, stride=1,
                                weights_initializer=tf.random_normal_initializer(0, 0.01))

        layer4_end = tf.concat([layer4_2, sub4_2_relu], 3)

        print layer4_end.get_shape()

    with tf.variable_scope('layer5'):

        dec4_relu = ly.conv2d_transpose(layer4_end,
                                        num_outputs=256, kernel_size=5, stride=2,
                                        weights_initializer=tf.random_normal_initializer(0, 0.01))

        layer5_1 = ly.conv2d(dec4_relu,
                             num_outputs=128, kernel_size=3, stride=1,
                             weights_initializer=tf.random_normal_initializer(0, 0.01))

        layer5_2 = ly.conv2d(layer5_1,
                             num_outputs=128, kernel_size=3, stride=1,
                             weights_initializer=tf.random_normal_initializer(0, 0.01))

        sub5_1_relu = ly.conv2d(pool1,
                                num_outputs=32, kernel_size=5, stride=1,
                                weights_initializer=tf.random_normal_initializer(0, 0.01))

        sub5_2_relu = ly.conv2d(sub5_1_relu,
                                num_outputs=64, kernel_size=5, stride=1,
                                weights_initializer=tf.random_normal_initializer(0, 0.01))

        layer5_end = tf.concat([layer5_2, sub5_2_relu], 3)

        print layer5_end.get_shape()

    with tf.variable_scope('layer6'):

        dec5_relu = ly.conv2d_transpose(layer5_end,
                                        num_outputs=128, kernel_size=5, stride=2,
                                        weights_initializer=tf.random_normal_initializer(0, 0.01))

        dec0_relu = ly.conv2d(dec5_relu,
                              num_outputs=128, kernel_size=5, stride=1,
                              weights_initializer=tf.random_normal_initializer(0, 0.01))

        dec_relu = ly.conv2d(dec0_relu,
                              num_outputs=128, kernel_size=5, stride=1,
                              weights_initializer=tf.random_normal_initializer(0, 0.01))

        out = ly.conv2d(dec_relu,
                        num_outputs=1, kernel_size=5, stride=1,
                        weights_initializer=tf.random_normal_initializer(0, 0.01))

        # out = tf.clip_by_value(out, 0, scale_normalization)
        print out.get_shape()

    return out