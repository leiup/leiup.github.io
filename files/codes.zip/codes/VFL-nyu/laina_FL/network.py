import tensorflow as tf
import numpy as np
import tensorflow.contrib.layers as ly

# Define and initialize training parameters
std = 0.01
scale_normalization = 5

def variable_summaries(var):
  """Attach a lot of summaries to a Tensor (for TensorBoard visualization)."""
  with tf.name_scope('summaries'):
    mean = tf.reduce_mean(var)
    tf.summary.scalar('mean', mean)
    # with tf.name_scope('stddev'):
    #   stddev = tf.sqrt(tf.reduce_mean(tf.square(var - mean)))
    # tf.summary.scalar('stddev', stddev)
    # tf.summary.scalar('max', tf.reduce_max(var))
    # tf.summary.scalar('min', tf.reduce_min(var))
    tf.summary.histogram('histogram', var)

# define graph architecture
def my_cnn(pool5, label, image, train_fl):

    with tf.variable_scope('layer1'):

        pool5_size = pool5.get_shape().as_list()
        # focal length information
        train_fl = tf.stack([train_fl, train_fl, train_fl, train_fl, train_fl, train_fl, train_fl], 1)
        # train_fl = tf.to_float(train_fl, name='ToFloat')
        fl_1 = ly.fully_connected(train_fl, 64)
        fl_2 = ly.fully_connected(fl_1, 256 * pool5_size[1] * pool5_size[2])

        relu5_flat = tf.reshape(fl_2, [-1, pool5_size[1], pool5_size[2], 256])

        fc_fuse = tf.concat([pool5, relu5_flat], 3)

        # fully convolution
        fc2_layer_1 = ly.conv2d(fc_fuse,
                                num_outputs=1024, kernel_size=1, stride=1,
                                weights_initializer=tf.random_normal_initializer(0, 0.01))

        fc2_layer_2 = UnPooling2x2ZeroFilled(fc2_layer_1)

        layer_up_1 = ly.conv2d(fc2_layer_2,
                             num_outputs=512, kernel_size=5, stride=1,
                             weights_initializer=tf.random_normal_initializer(0, 0.01))

        layer_up_2 = ly.conv2d(layer_up_1,
                             num_outputs=512, kernel_size=3, stride=1,
                             weights_initializer=tf.random_normal_initializer(0, 0.01), activation_fn=None)

        layer_down_1 = ly.conv2d(fc2_layer_2,
                             num_outputs=512, kernel_size=5, stride=1,
                             weights_initializer=tf.random_normal_initializer(0, 0.01), activation_fn=None)

        layer1_end = tf.nn.relu(layer_up_2 + layer_down_1)

        print layer1_end.get_shape()

    with tf.variable_scope('layer2'):

        fc2_layer_2 = UnPooling2x2ZeroFilled(layer1_end)

        layer_up_1 = ly.conv2d(fc2_layer_2,
                             num_outputs=256, kernel_size=5, stride=1,
                             weights_initializer=tf.random_normal_initializer(0, 0.01))

        layer_up_2 = ly.conv2d(layer_up_1,
                             num_outputs=256, kernel_size=3, stride=1,
                             weights_initializer=tf.random_normal_initializer(0, 0.01), activation_fn=None)

        layer_down_1 = ly.conv2d(fc2_layer_2,
                             num_outputs=256, kernel_size=5, stride=1,
                             weights_initializer=tf.random_normal_initializer(0, 0.01), activation_fn=None)

        layer2_end = tf.nn.relu(layer_up_2 + layer_down_1)

        print layer2_end.get_shape()

    with tf.variable_scope('layer3'):

        fc2_layer_2 = UnPooling2x2ZeroFilled(layer2_end)

        layer_up_1 = ly.conv2d(fc2_layer_2,
                             num_outputs=128, kernel_size=5, stride=1,
                             weights_initializer=tf.random_normal_initializer(0, 0.01))

        layer_up_2 = ly.conv2d(layer_up_1,
                             num_outputs=128, kernel_size=3, stride=1,
                             weights_initializer=tf.random_normal_initializer(0, 0.01), activation_fn=None)

        layer_down_1 = ly.conv2d(fc2_layer_2,
                             num_outputs=128, kernel_size=5, stride=1,
                             weights_initializer=tf.random_normal_initializer(0, 0.01), activation_fn=None)

        layer3_end = tf.nn.relu(layer_up_2 + layer_down_1)

        print layer3_end.get_shape()

    with tf.variable_scope('layer4'):

        fc2_layer_2 = UnPooling2x2ZeroFilled(layer3_end)

        layer_up_1 = ly.conv2d(fc2_layer_2,
                             num_outputs=64, kernel_size=5, stride=1,
                             weights_initializer=tf.random_normal_initializer(0, 0.01))

        layer_up_2 = ly.conv2d(layer_up_1,
                             num_outputs=64, kernel_size=3, stride=1,
                             weights_initializer=tf.random_normal_initializer(0, 0.01), activation_fn=None)

        layer_down_1 = ly.conv2d(fc2_layer_2,
                             num_outputs=64, kernel_size=5, stride=1,
                             weights_initializer=tf.random_normal_initializer(0, 0.01), activation_fn=None)

        layer4_end = tf.nn.relu(layer_up_2 + layer_down_1)

        print layer4_end.get_shape()

    with tf.variable_scope('layer5'):

        fc2_layer_2 = UnPooling2x2ZeroFilled(layer4_end)

        layer_up_1 = ly.conv2d(fc2_layer_2,
                             num_outputs=64, kernel_size=5, stride=1,
                             weights_initializer=tf.random_normal_initializer(0, 0.01))

        layer_up_2 = ly.conv2d(layer_up_1,
                             num_outputs=64, kernel_size=3, stride=1,
                             weights_initializer=tf.random_normal_initializer(0, 0.01), activation_fn=None)

        layer_down_1 = ly.conv2d(fc2_layer_2,
                             num_outputs=64, kernel_size=5, stride=1,
                             weights_initializer=tf.random_normal_initializer(0, 0.01), activation_fn=None)

        layer5_end = tf.nn.relu(layer_up_2 + layer_down_1)

        print layer5_end.get_shape()

    with tf.variable_scope('layer6'):

        out = ly.conv2d(layer5_end,
                        num_outputs=1, kernel_size=5, stride=1,
                        weights_initializer=tf.random_normal_initializer(0, 0.01))

        # out = tf.clip_by_value(out, 0, scale_normalization)
        print out.get_shape()

    return out

# data un_pooling
def UnPooling2x2ZeroFilled(x):
    out = tf.concat([x, tf.zeros_like(x)], 3)
    out = tf.concat([out, tf.zeros_like(out)], 2)

    sh = x.get_shape().as_list()
    if None not in sh[1:]:
        out_size = [-1, sh[1] * 2, sh[2] * 2, sh[3]]
        return tf.reshape(out, out_size)
    else:
        shv = tf.shape(x)
        ret = tf.reshape(out, tf.pack([-1, shv[1] * 2, shv[2] * 2, sh[3]]))
        ret.set_shape([None, None, None, sh[3]])
        return ret