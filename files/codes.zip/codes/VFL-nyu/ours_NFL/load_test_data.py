
import tensorflow as tf
import random
import numpy as np
# from input_preprocess import *
import time
from tensorflow.python.framework import ops
from tensorflow.python.framework import dtypes
import csv
import os

dataset_path = os.getcwd() + "/"
org_file = "data.csv"

# multi focal length dataset
test_set_size = 654
IMAGE_HEIGHT = 480
IMAGE_WIDTH = 640

# read file from disk
def read_label_org(file):
    with open(file) as f_obj:
        f = csv.DictReader(f_obj, delimiter=',')
        print f
        data_file = []
        label_file = []
        for line in f:
            data = line["image"]
            label = line["depth"]
            data_file.append(data)
            label_file.append(label.strip())
        return data_file, label_file

# data input_pipeline
def input_pipeline(argv=None):
    # reading labels and file path
    data_org, label_org = read_label_org(dataset_path + org_file)

    data_filepaths = [dataset_path + fp for fp in data_org]
    label_filepaths = [dataset_path + fp for fp in label_org]

    # convert string into tensors
    all_images = ops.convert_to_tensor(data_filepaths, dtype=dtypes.string)
    all_labels = ops.convert_to_tensor(label_filepaths, dtype=dtypes.string)

    # create a partition vector
    partition = [0] * 1449
    partition[:test_set_size] = [1] * test_set_size
    partitions = partition * 7
    
    # partition our data into a test and train set according to our partition vector
    train_images, test_images = tf.dynamic_partition(all_images, partitions, 2)
    train_labels, test_labels = tf.dynamic_partition(all_labels, partitions, 2)

    test_input_queue_image = tf.train.slice_input_producer(
        [test_images],
        shuffle=False)

    test_input_queue_label = tf.train.slice_input_producer(
        [test_labels],
        shuffle=False)

    file_content_test_data = tf.read_file(test_input_queue_image[0])
    test_image = tf.image.decode_jpeg(file_content_test_data, channels=3)
    test_image = tf.cast(test_image, dtype=np.float32)
    # test_image = test_image * 1 / 256.
    #  test_image = tf.image.convert_image_dtype(test_image, dtype=tf.uint8)

    file_content_test_label = tf.read_file(test_input_queue_label[0])
    test_label = tf.image.decode_png(file_content_test_label, channels=1, dtype=tf.uint16)
    test_label = tf.cast(test_label, dtype=np.float32)
    test_label = test_label * 1 / 10 ** 4.

    test_image = tf.image.resize_images(test_image, [224, 320])
    test_label = tf.image.resize_images(test_label, [480, 640])

    test_image.set_shape([224, 320, 3])
    test_label.set_shape([480, 640, 1])

    test_image = tf.expand_dims(test_image, 0)
    test_label = tf.expand_dims(test_label, 0)

    print "input pipeline ready"
    return test_image, test_label