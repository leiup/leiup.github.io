
import tensorflow as tf
import random
import numpy as np
import time
from tensorflow.python.framework import ops
from tensorflow.python.framework import dtypes
import csv
import os
import math

dataset_path = os.getcwd() + "/"
org_file = "data.csv"

# multi focal length dataset
test_set_size = 654
IMAGE_HEIGHT = 480
IMAGE_WIDTH = 640

# read file from disk
def read_label_org(file):
    with open(file) as f_obj:
        f = csv.DictReader(f_obj, delimiter=',')
        print f
        data_file = []
        label_file = []   
        for line in f:
            data = line["image"]
            label = line["depth"]
            data_file.append(data)
            label_file.append(label.strip())
        return data_file, label_file

# data input_pipeline
def input_pipeline(argv=None):
    # reading labels and file path
    data_org, label_org = read_label_org(dataset_path + org_file)

    data_filepaths = [dataset_path + fp for fp in data_org]
    label_filepaths = [dataset_path + fp for fp in label_org]

    # convert string into tensors
    all_images = ops.convert_to_tensor(data_filepaths, dtype=dtypes.string)
    all_labels = ops.convert_to_tensor(label_filepaths, dtype=dtypes.string)

    # create a partition vector
    partition = [0] * 1449
    partition[:test_set_size] = [1] * test_set_size
    partitions = partition * 7

    # partition our data into a test and train set according to our partition vector
    train_images, test_images = tf.dynamic_partition(all_images, partitions, 2)
    train_labels, test_labels = tf.dynamic_partition(all_labels, partitions, 2)

    # create input queues
    train_input_queue_image = tf.train.slice_input_producer(
        [train_images],
        shuffle=False)

    train_input_queue_label = tf.train.slice_input_producer(
        [train_labels],
        shuffle=False)

    # process path and string tensor into an image and a label
    file_content_train_data = tf.read_file(train_input_queue_image[0])
    train_image = tf.image.decode_jpeg(file_content_train_data, channels=3)
    train_image = tf.cast(train_image, dtype=np.float32)
    # train_image = train_image * 1 / 256.
    # print train_image.get_shape()

    file_content_train_label = tf.read_file(train_input_queue_label[0])
    train_label = tf.image.decode_png(file_content_train_label, channels=1, dtype=tf.uint16)
    train_label = tf.cast(train_label, dtype=np.float32)
    train_label = train_label / 10 ** 4

    # Training data argumentation #
    distortions = tf.random_uniform([6], 0, 1.0, dtype=tf.float32)

    # flip left and right transformation #
    value_flip = np.random.rand(1) * 100000
    value_flip = np.floor(value_flip)
    train_image = tf.image.random_flip_left_right(train_image, seed=value_flip)
    train_label = tf.image.random_flip_left_right(train_label, seed=value_flip)

    # scale rgb and d randomly [1, 1.2, 1.5] #
    def scale_transform(train_image, train_label, IMAGE_HEIGHT, IMAGE_WIDTH):
        # list = [1, 1.2, 1.5]
        # scale_list = random.sample(list, 1)
        # scale = scale_list[0]
        randn = 1 + distortions[1]/2
        scale = tf.to_float(tf.to_int32(randn*10, name='ToInt32'), name='ToFloat')/10.
        new_height = tf.to_int32(IMAGE_HEIGHT * scale, name='ToInt32')
        new_width = tf.to_int32(IMAGE_WIDTH * scale, name='ToInt32')
        train_image_new = tf.image.resize_images(train_image, [new_height, new_width], 0)
        train_label_new = tf.image.resize_images(train_label, [new_height, new_width], 0)
        train_label_new = train_label_new / scale
        train_image = tf.image.resize_image_with_crop_or_pad(train_image_new, IMAGE_HEIGHT, IMAGE_WIDTH)
        train_label = tf.image.resize_image_with_crop_or_pad(train_label_new, IMAGE_HEIGHT, IMAGE_WIDTH)
        return train_image, train_label

    train_image, train_label = scale_transform(train_image, train_label, 480, 640)

    # color transformation #
    color_factor = 0.8 + 0.4*distortions[1]
    train_image = train_image * color_factor

    # crop and pad transformation #
    value = np.random.rand(1) * 100000
    value = np.floor(value)

    def crop_pading(train_image, train_label, min_h, min_w):
        height_crop = min_h + distortions[4] * (IMAGE_HEIGHT - min_h)
        height_crop = tf.to_int32(height_crop, name='ToInt32')

        width_crop = min_w + distortions[5] * (IMAGE_WIDTH - min_w)
        width_crop = tf.to_int32(width_crop, name='ToInt32')

        train_image = tf.random_crop(train_image, [height_crop, width_crop, 3], seed=value)
        train_label = tf.random_crop(train_label, [height_crop, width_crop, 1], seed=value)

        train_image = tf.image.pad_to_bounding_box(train_image,
                                                   IMAGE_HEIGHT - height_crop, IMAGE_WIDTH - width_crop, IMAGE_HEIGHT, IMAGE_WIDTH)
        train_label = tf.image.pad_to_bounding_box(train_label,
                                                   IMAGE_HEIGHT - height_crop, IMAGE_WIDTH - width_crop, IMAGE_HEIGHT, IMAGE_WIDTH)
        return train_image, train_label

    def identity(train_image, train_label):

        # train_image = tf.random_crop(train_image, [448, 320, 3], seed=value)
        # train_label = tf.random_crop(train_label, [448, 320, 1], seed=value)
        return train_image, train_label

    # train_image, train_label = tf.cond(distortions[3] > 0.5, lambda: crop_pading(train_image, train_label, 240, 320),
    #                                    lambda: identity(train_image, train_label))

    # resize #
    train_image = tf.image.resize_images(train_image, [224, 320])
    train_label = tf.image.resize_images(train_label, [224, 320])

    train_image.set_shape([224, 320, 3])
    train_label.set_shape([224, 320, 1])

    # rotation transformation #
    def rotation_transform(train_image, train_label):
        list = [-30, 30]
        rot_list = random.sample(list, 1)
        rot_angular = rot_list[0]
        train_image = rotate(train_image, rot_angular)
        train_label = rotate(train_label, rot_angular)
        return train_image, train_label

    # train_image, train_label = tf.cond(distortions[4] > 0.5, lambda: rotation_transform(train_image, train_label),
    #                                    lambda: identity(train_image, train_label))

    images_batch, labels_batch = tf.train.shuffle_batch(
        [train_image, train_label],
        batch_size=8,
        capacity=4000,
        min_after_dequeue=1000)

#    images_batch = tf.expand_dims(images_batch, 0)
#    labels_batch = tf.expand_dims(labels_batch, 0)

    print "input pipeline ready"
    return images_batch, labels_batch

def rotate(image, angle):
    with tf.name_scope('rotate'):
        image = tf.cast(image, tf.float32)
        angle = angle / 180 * math.pi
        shape = image.get_shape().as_list()
        assert len(shape) == 3, "Input needs to be 3D."
        image_center = np.array([x/2 for x in shape][:-1])

        coord1 = tf.cast(tf.range(shape[0]), tf.float32)
        coord2 = tf.cast(tf.range(shape[1]), tf.float32)

        # Create vectors of those coordinates in order to vectorize the image
        coord1_vec = tf.tile(coord1, [shape[1]])

        coord2_vec_unordered = tf.tile(coord2, [shape[0]])
        coord2_vec_unordered = tf.reshape(coord2_vec_unordered, [shape[0], shape[1]])
        coord2_vec = tf.reshape(tf.transpose(coord2_vec_unordered, [1, 0]), [-1])

        # center coordinates since rotation center is supposed to be in the image center
        coord1_vec_centered = coord1_vec - image_center[0]
        coord2_vec_centered = coord2_vec - image_center[1]

        coord_new_centered = tf.cast(tf.stack([coord1_vec_centered, coord2_vec_centered]), tf.float32)

        # Perform backward transformation of the image coordinates
        rot_mat_inv = tf.expand_dims(tf.stack([tf.cos(angle), tf.sin(angle), -tf.sin(angle), tf.cos(angle)]), 0)
        rot_mat_inv = tf.cast(tf.reshape(rot_mat_inv, shape=[2, 2]), tf.float32)
        coord_old_centered = tf.matmul(rot_mat_inv, coord_new_centered)

        # Find neighbors in old image
        coord1_old_nn = coord_old_centered[0, :] + image_center[0]
        coord2_old_nn = coord_old_centered[1, :] + image_center[1]

        # Clip values to stay inside image coordinates
        outside_ind1 = tf.logical_or(tf.greater(coord1_old_nn, shape[0]-1), tf.less(coord1_old_nn, 0))
        outside_ind2 = tf.logical_or(tf.greater(coord2_old_nn, shape[1]-1), tf.less(coord2_old_nn, 0))
        outside_ind = tf.logical_or(outside_ind1, outside_ind2)

        coord1_vec = tf.boolean_mask(coord1_vec, tf.logical_not(outside_ind))
        coord2_vec = tf.boolean_mask(coord2_vec, tf.logical_not(outside_ind))

        # Coordinates of the new image
        coord_new = tf.transpose(tf.cast(tf.stack([coord1_vec, coord2_vec]), tf.int32), [1, 0])

        coord1_old_nn0 = tf.floor(coord1_old_nn)
        coord2_old_nn0 = tf.floor(coord2_old_nn)
        sx = coord1_old_nn - coord1_old_nn0
        sy = coord2_old_nn - coord2_old_nn0
        coord1_old_nn0 = tf.cast(coord1_old_nn0, tf.int32)
        coord2_old_nn0 = tf.cast(coord2_old_nn0, tf.int32)
        coord1_old_nn0 = tf.boolean_mask(coord1_old_nn0, tf.logical_not(outside_ind))
        coord2_old_nn0 = tf.boolean_mask(coord2_old_nn0, tf.logical_not(outside_ind))
        coord1_old_nn1 = coord1_old_nn0 + 1
        coord2_old_nn1 = coord2_old_nn0 + 1
        interp_coords = [
            ((1.-sx) * (1.-sy), coord1_old_nn0, coord2_old_nn0),
            (    sx  * (1.-sy), coord1_old_nn1, coord2_old_nn0),
            ((1.-sx) *     sy,  coord1_old_nn0, coord2_old_nn1),
            (    sx  *     sy,  coord1_old_nn1, coord2_old_nn1)
        ]

        interp_old = []
        for intensity, coord1, coord2 in interp_coords:
            intensity = tf.transpose(tf.reshape(intensity, [shape[1], shape[0]]))
            coord_old_clipped = tf.transpose(tf.stack([coord1, coord2]), [1, 0])
            interp_old.append((intensity, coord_old_clipped))

        channels = tf.split(image, shape[2], 2)
        image_rotated_channel_list = list()
        for channel in channels:
            channel = tf.squeeze(channel)
            interp_intensities = []
            for intensity, coord_old_clipped in interp_old:
                image_chan_new_values = tf.gather_nd(channel, coord_old_clipped)

                channel_values = tf.sparse_to_dense(coord_new, [shape[0], shape[1]], image_chan_new_values,
                                                    0, validate_indices=False)

                interp_intensities.append(channel_values * intensity)
            image_rotated_channel_list.append(tf.add_n(interp_intensities))

        image_rotated = tf.transpose(tf.stack(image_rotated_channel_list), [1, 2, 0])

        return image_rotated
