
from load_train_data import *
from network import *
# from show_image import *
import vgg19_trainable as vgg19

dataset_path = "models/"
model_path = dataset_path + "model.ckpt"

def main(argv=None):
    graph = tf.get_default_graph()
    with graph.as_default():

        # load data
        train_image, train_label = input_pipeline()
        is_test = tf.cast(0, dtype=tf.bool)

        # Construct model
        # vgg_net = vgg.Vgg16()
        # vgg_net.build(train_image)
        # pool5 = vgg_net.conv5_3
        # pool4 = vgg_net.conv4_3
        # pool3 = vgg_net.conv3_3
        # pool2 = vgg_net.conv2_2
        # pool1 = vgg_net.conv1_2

        vgg_net = vgg19.Vgg19('./vgg19.npy')
        vgg_net.build(train_image)
        pool5 = vgg_net.conv5_4

        # print(vgg_net.get_var_count())

        prediction_depth = my_cnn(pool5, train_label, train_image)

        # prediction_depth = tf.image.resize_images(prediction_depth, [IMAGE_HEIGHT, IMAGE_WIDTH])

        for variable in tf.trainable_variables():
            print(variable)

        # deconv4, deconv3, deconv2, deconv1, prediction_depth, update_ema \
        #     = my_cnn(pool5, pool4, pool3, pool2, pool1, is_test, train_image)

        # Vaild pixels mask
        mask = (train_label > 0) & (train_label < 10)

        matrix_valid = tf.cast(mask, tf.float32)
        num_vaild = tf.reduce_sum(matrix_valid)

        depth_error = tf.abs(prediction_depth - train_label)
        depth_error = tf.multiply(depth_error, matrix_valid)
        c = 0.1 * tf.reduce_max(depth_error)

        # l1 and l2 loss
        loss = tf.reduce_sum(depth_error)
        depth_loss = loss
        l1_loss = depth_loss

        l2_loss = tf.nn.l2_loss(depth_error) + c**2
        l2_loss = l2_loss / 2*c
        # l2_loss = tf.nn.l2_loss(depth_error)

        tmp = depth_loss / num_vaild

        depth_loss_end = tf.cond(tmp > c, lambda: l2_loss, lambda: l1_loss)
        # depth_loss_end = l1_loss

        depth_loss_end = depth_loss_end / num_vaild
        # Optimizer: set up a variable that's incremented once per batch and controls the learning rate decay.
        global_step = tf.Variable(0)
        optimizer = tf.train.AdamOptimizer(1e-4, 0.9, 0.99).minimize(depth_loss_end, global_step)

        # Initializaing the variables
        init = tf.global_variables_initializer()

        # 'Saver' op to save and restore all the variables
        saver = tf.train.Saver()

        # merge all the summaries and write them out to /tmp/logs
        # merged = tf.summary.merge_all()

        total_parameters = 0
        for variable in tf.trainable_variables():

            print(variable)

        print(total_parameters)

        start_time = time.time()
        # Running session
        print "Starting session... "
        with tf.Session() as sess:

            # initialize the variables
            sess.run(init)

            # initialize the queue threads to start to shovel data
            coord = tf.train.Coordinator()
            threads = tf.train.start_queue_runners(coord=coord)

            # Restore model weights from previously saved model
            # load_path = saver.restore(sess, model_path1)
            # print "Model restored from file: %s" % model_path1

            # train_writer = tf.summary.FileWriter('/tmp/logs' + '/train', sess.graph)

            print "from the train set:"
            for i in range(80000):
                _, d, pre_depth, train_image_aug1, train_label_aug1, max_err, loss_m = \
                    sess.run([optimizer, depth_loss_end, prediction_depth, train_image, train_label, c, tmp])

                if i % 100 == 0:
                    print('Training step %d, loss is: %f, c is: %f, tmp is: %f' % (i, d, max_err, loss_m))
                    # show_image(pre_depth, train_image_aug1, train_label_aug1, 8)
                    # train_writer.add_summary(summary, i)

                    # file = 'test_results_transformation_net_fully_convolution/' + str(i) + '.png'
                    # pre_depth = np.squeeze(pre_depth)
                    # pre_depth = pre_depth / 100.
                    # pre_depth = pre_depth * 2 ** 16
                    # pre_depth = pre_depth.astype('uint16')
                    # cv2.imwrite(file, pre_depth)

            print "Training Finished!"

            # Save the variables to disk.
            save_path = saver.save(sess, model_path)
            print("Model saved in file: %s" % save_path)

            # train_writer.close()

            # stop our queue threads and properly close the session
            coord.request_stop()
            coord.join(threads)
            sess.close()

            elapsed_time = time.time() - start_time
            training_time = elapsed_time / 3600.
            print("Training time is: %f hours" % training_time)

if __name__ == '__main__':
    main()
