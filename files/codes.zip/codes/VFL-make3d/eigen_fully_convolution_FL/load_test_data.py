
import tensorflow as tf
import random
import numpy as np
# from input_preprocess import *
import time
from tensorflow.python.framework import ops
from tensorflow.python.framework import dtypes
import csv
import os

dataset_path = os.getcwd() + "/"
dataset_file = "data_focal_length.csv"

# multi focal length dataset
test_set_size = 134
IMAGE_HEIGHT = 460
IMAGE_WIDTH = 345

# read file from disk
def read_label_file(file):
    f = open(file, "r")
    data_file = []
    label_file = []
    fl_index_file = []
    for line in f:
        data, label, fl_index = line.strip().split(",")
        data_file.append(data)
        label_file.append(label)
        fl_index_file.append(fl_index.strip())
    return data_file, label_file, fl_index_file

def input_pipeline(argv=None):
    # reading labels and file path
    data, label, fl_index = read_label_file(dataset_path + dataset_file)

    data_filepaths = [dataset_path + fp for fp in data]
    label_filepaths = [dataset_path + fp for fp in label]
    fl_filepaths = fl_index
    # print data_filepaths
    # print fl_filepaths

    # convert string into tensors
    all_images = ops.convert_to_tensor(data_filepaths, dtype=dtypes.string)
    all_labels = ops.convert_to_tensor(label_filepaths, dtype=dtypes.string)
    # fl_filepaths = ops.convert_to_tensor(fl_filepaths, dtype=dtypes.string)

    # create a partition vector
    partition = [0] * 534
    partition[:test_set_size] = [1] * test_set_size
    partitions = partition * 7

    # partition our data into a test and train set according to our partition vector
    train_images, test_images = tf.dynamic_partition(all_images, partitions, 2)
    train_labels, test_labels = tf.dynamic_partition(all_labels, partitions, 2)
    train_fls, test_fls = tf.dynamic_partition(fl_filepaths, partitions, 2)

    # create input queues
    test_input_queue_image = tf.train.slice_input_producer(
        [test_images],
        shuffle=False)

    test_input_queue_label = tf.train.slice_input_producer(
        [test_labels],
        shuffle=False)

    test_input_queue_fl = tf.train.slice_input_producer(
        [test_fls],
        shuffle=False)

    # process path and string tensor into an image and a label
    file_content_test_data = tf.read_file(test_input_queue_image[0])
    test_images = tf.image.decode_jpeg(file_content_test_data, channels=3)
    test_image = tf.cast(test_images, dtype=np.float32)
    # train_image = train_image * 1 / 256.
    # print train_image.get_shape()

    file_content_test_label = tf.read_file(test_input_queue_label[0])
    test_labels = tf.image.decode_png(file_content_test_label, channels=1, dtype=tf.uint16)
    test_labels = tf.cast(test_labels, dtype=np.float32)
    test_label = test_labels * 100 / 65536

    # file_content_train_fl = tf.read_file(train_input_queue_fl[0])
    # train_fl = train_input_queue_fl[0]
    test_fl = tf.string_to_number(test_input_queue_fl[0], tf.float32)

    test_image = tf.image.resize_images(test_image, [224, 160])
    test_label = tf.image.resize_images(test_label, [460, 345])

    test_image.set_shape([224, 160, 3])
    test_label.set_shape([460, 345, 1])

    test_image = tf.expand_dims(test_image, 0)
    test_label = tf.expand_dims(test_label, 0)
    test_fl = tf.expand_dims(test_fl, 0)

    print "input pipeline ready"
    return test_image, test_label, test_fl