
import tensorflow as tf
import random
import numpy as np
import time
from tensorflow.python.framework import ops
from tensorflow.python.framework import dtypes
import csv
import os
import math

dataset_path = os.getcwd() + "/"
dataset_file = "data_focal_length.csv"

# multi focal length dataset
test_set_size = 134
IMAGE_HEIGHT = 460
IMAGE_WIDTH = 345

# read file from disk
def read_label_file(file):
    f = open(file, "r")
    data_file = []
    label_file = []
    fl_index_file = []
    for line in f:
        data, label, fl_index = line.strip().split(",")
        data_file.append(data)
        label_file.append(label)
        fl_index_file.append(fl_index.strip())
    return data_file, label_file, fl_index_file

# data input_pipeline
def input_pipeline(argv=None):
    # reading labels and file path
    data, label, fl_index = read_label_file(dataset_path + dataset_file)

    data_filepaths = [dataset_path + fp for fp in data]
    label_filepaths = [dataset_path + fp for fp in label]
    fl_filepaths = fl_index
    # print data_filepaths
    # print fl_filepaths

    # convert string into tensors
    all_images = ops.convert_to_tensor(data_filepaths, dtype=dtypes.string)
    all_labels = ops.convert_to_tensor(label_filepaths, dtype=dtypes.string)
    # fl_filepaths = ops.convert_to_tensor(fl_filepaths, dtype=dtypes.string)

    # create a partition vector
    partition = [0] * 534
    partition[:test_set_size] = [1] * test_set_size
    partitions = partition * 7

    # partition our data into a test and train set according to our partition vector
    train_images, test_images = tf.dynamic_partition(all_images, partitions, 2)
    train_labels, test_labels = tf.dynamic_partition(all_labels, partitions, 2)
    train_fls, test_fls = tf.dynamic_partition(fl_filepaths, partitions, 2)

    # create input queues
    train_input_queue_image = tf.train.slice_input_producer(
        [train_images],
        shuffle=False)

    train_input_queue_label = tf.train.slice_input_producer(
        [train_labels],
        shuffle=False)

    train_input_queue_fl = tf.train.slice_input_producer(
        [train_fls],
        shuffle=False)

    # process path and string tensor into an image and a label
    file_content_train_data = tf.read_file(train_input_queue_image[0])
    train_image = tf.image.decode_jpeg(file_content_train_data, channels=3)
    train_image = tf.cast(train_image, dtype=np.float32)
    # train_image = train_image * 1 / 256.
    # print train_image.get_shape()

    file_content_train_label = tf.read_file(train_input_queue_label[0])
    train_label = tf.image.decode_png(file_content_train_label, channels=1, dtype=tf.uint16)
    train_label = tf.cast(train_label, dtype=np.float32)
    train_label = train_label * 100 / 65536

    # file_content_train_fl = tf.read_file(train_input_queue_fl[0])
    # train_fl = train_input_queue_fl[0]
    train_fl = tf.string_to_number(train_input_queue_fl[0], tf.float32)

    # Training data argumentation #
    distortions = tf.random_uniform([6], 0, 1.0, dtype=tf.float32)

    # flip left and right transformation #
    value_flip = np.random.rand(1) * 100000
    value_flip = np.floor(value_flip)
    train_image = tf.image.random_flip_left_right(train_image, seed=value_flip)
    train_label = tf.image.random_flip_left_right(train_label, seed=value_flip)

    # scale rgb and d randomly [1, 1.2, 1.5] #
    def scale_transform(train_image, train_label, IMAGE_HEIGHT, IMAGE_WIDTH):
        randn = 1 + distortions[1]/2
        scale = tf.to_float(tf.to_int32(randn*10, name='ToInt32'), name='ToFloat')/10.
        new_height = tf.to_int32(IMAGE_HEIGHT * scale, name='ToInt32')
        new_width = tf.to_int32(IMAGE_WIDTH * scale, name='ToInt32')
        train_image_new = tf.image.resize_images(train_image, [new_height, new_width], 0)
        train_label_new = tf.image.resize_images(train_label, [new_height, new_width], 0)
        train_label_new = train_label_new / scale
        train_image = tf.image.resize_image_with_crop_or_pad(train_image_new, IMAGE_HEIGHT, IMAGE_WIDTH)
        train_label = tf.image.resize_image_with_crop_or_pad(train_label_new, IMAGE_HEIGHT, IMAGE_WIDTH)
        return train_image, train_label

    train_image, train_label = scale_transform(train_image, train_label, IMAGE_HEIGHT, IMAGE_WIDTH)

    # color transformation #
    color_factor = 0.8 + 0.4*distortions[1]
    train_image = train_image * color_factor

    # resize #
    train_image = tf.image.resize_images(train_image, [224, 160])
    train_label = tf.image.resize_images(train_label, [224, 160])

    train_image.set_shape([224, 160, 3])
    train_label.set_shape([224, 160, 1])

    images_batch, labels_batch, fl_batch = tf.train.shuffle_batch([train_image, train_label, train_fl],
        batch_size=8,
        capacity=4000,
        min_after_dequeue=1000)

    #    images_batch = tf.expand_dims(images_batch, 0)
    #    labels_batch = tf.expand_dims(labels_batch, 0)

    print "input pipeline ready"
    return images_batch, labels_batch, fl_batch