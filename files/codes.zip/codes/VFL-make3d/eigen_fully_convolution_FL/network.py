import tensorflow as tf
import numpy as np
import tensorflow.contrib.layers as ly

# Define and initialize training parameters
std = 0.01
scale_normalization = 5

def variable_summaries(var):
  """Attach a lot of summaries to a Tensor (for TensorBoard visualization)."""
  with tf.name_scope('summaries'):
    mean = tf.reduce_mean(var)
    tf.summary.scalar('mean', mean)
    # with tf.name_scope('stddev'):
    #   stddev = tf.sqrt(tf.reduce_mean(tf.square(var - mean)))
    # tf.summary.scalar('stddev', stddev)
    # tf.summary.scalar('max', tf.reduce_max(var))
    # tf.summary.scalar('min', tf.reduce_min(var))
    tf.summary.histogram('histogram', var)

# define graph architecture
def my_cnn(pool5, label, image, train_fl):

    with tf.variable_scope('layer1'):
        pool5_size = pool5.get_shape().as_list()
        # focal length information
        train_fl = tf.stack([train_fl, train_fl, train_fl, train_fl, train_fl, train_fl, train_fl], 1)
        # train_fl = tf.to_float(train_fl, name='ToFloat')
        fl_1 = ly.fully_connected(train_fl, 64)
        fl_2 = ly.fully_connected(fl_1, 256 * pool5_size[1] * pool5_size[2])

        relu5_flat = tf.reshape(fl_2, [-1, pool5_size[1], pool5_size[2], 256])

        fc_fuse = tf.concat([pool5, relu5_flat], 3)

        scale_1 = ly.conv2d_transpose(fc_fuse,
                                      num_outputs=256, kernel_size=9, stride=4,
                                      weights_initializer=tf.random_normal_initializer(0, 0.01))

        image_1 = ly.conv2d(image,
                            num_outputs=256, kernel_size=9, stride=2,
                            weights_initializer=tf.random_normal_initializer(0, 0.01))

        image_1_pool = tf.nn.max_pool(image_1, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1], padding='SAME')

        layer1_end = tf.concat([scale_1, image_1_pool], 3)

        print layer1_end.get_shape()

    with tf.variable_scope('layer2'):

        layer2_1 = ly.conv2d(layer1_end,
                             num_outputs=128, kernel_size=9, stride=1,
                             weights_initializer=tf.random_normal_initializer(0, 0.01))

        layer2_2 = ly.conv2d(layer2_1,
                             num_outputs=128, kernel_size=5, stride=1,
                             weights_initializer=tf.random_normal_initializer(0, 0.01))

        layer2_3 = ly.conv2d(layer2_2,
                             num_outputs=128, kernel_size=5, stride=1,
                             weights_initializer=tf.random_normal_initializer(0, 0.01))

        layer2_4 = ly.conv2d(layer2_3,
                             num_outputs=128, kernel_size=5, stride=1,
                             weights_initializer=tf.random_normal_initializer(0, 0.01))

        layer2_5 = ly.conv2d(layer2_4,
                             num_outputs=128, kernel_size=5, stride=1,
                             weights_initializer=tf.random_normal_initializer(0, 0.01))

        scale_2 = ly.conv2d_transpose(layer2_5,
                                      num_outputs=128, kernel_size=5, stride=2,
                                      weights_initializer=tf.random_normal_initializer(0, 0.01))

        image_2 = ly.conv2d(image,
                            num_outputs=128, kernel_size=9, stride=1,
                            weights_initializer=tf.random_normal_initializer(0, 0.01))

        image_2_pool = tf.nn.max_pool(image_2, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1], padding='SAME')

        layer2_end = tf.concat([scale_2, image_2_pool], 3)

        print layer2_end.get_shape()

    with tf.variable_scope('layer3'):

        layer3_1 = ly.conv2d(layer2_end,
                             num_outputs=64, kernel_size=9, stride=1,
                             weights_initializer=tf.random_normal_initializer(0, 0.01))

        layer3_2 = ly.conv2d(layer3_1,
                             num_outputs=64, kernel_size=5, stride=1,
                             weights_initializer=tf.random_normal_initializer(0, 0.01))

        layer3_3 = ly.conv2d(layer3_2,
                             num_outputs=64, kernel_size=5, stride=1,
                             weights_initializer=tf.random_normal_initializer(0, 0.01))

        layer3_4 = ly.conv2d(layer3_3,
                             num_outputs=64, kernel_size=5, stride=1,
                             weights_initializer=tf.random_normal_initializer(0, 0.01))

        scale_3 = ly.conv2d_transpose(layer3_4,
                                      num_outputs=64, kernel_size=5, stride=2,
                                      weights_initializer=tf.random_normal_initializer(0, 0.01))

        scale_3_end = ly.conv2d(scale_3,
                            num_outputs=64, kernel_size=5, stride=1,
                            weights_initializer=tf.random_normal_initializer(0, 0.01))

        out = ly.conv2d(scale_3_end,
                        num_outputs=1, kernel_size=5, stride=1,
                        weights_initializer=tf.random_normal_initializer(0, 0.01))

        # out = tf.clip_by_value(out, 0, scale_normalization)
        print out.get_shape()

    return out