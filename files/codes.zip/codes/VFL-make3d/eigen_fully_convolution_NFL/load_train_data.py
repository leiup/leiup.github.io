
import tensorflow as tf
import random
import numpy as np
import time
from tensorflow.python.framework import ops
from tensorflow.python.framework import dtypes
import csv
import os
import math

dataset_path = os.getcwd() + "/"
org_file = "data.csv"

# multi focal length dataset
test_set_size = 134
IMAGE_HEIGHT = 460
IMAGE_WIDTH = 345

# read file from disk
def read_label_org(file):
    with open(file) as f_obj:
        f = csv.DictReader(f_obj, delimiter=',')
        print f
        data_file = []
        label_file = []   
        for line in f:
            data = line["image"]
            label = line["depth"]
            data_file.append(data)
            label_file.append(label.strip())
        return data_file, label_file

# data input_pipeline
def input_pipeline(argv=None):
    # reading labels and file path
    data_org, label_org = read_label_org(dataset_path + org_file)

    data_filepaths = [dataset_path + fp for fp in data_org]
    label_filepaths = [dataset_path + fp for fp in label_org]

    # convert string into tensors
    all_images = ops.convert_to_tensor(data_filepaths, dtype=dtypes.string)
    all_labels = ops.convert_to_tensor(label_filepaths, dtype=dtypes.string)

    # create a partition vector
    partition = [0] * 534
    partition[:test_set_size] = [1] * test_set_size
    partitions = partition * 7

    # partition our data into a test and train set according to our partition vector
    train_images, test_images = tf.dynamic_partition(all_images, partitions, 2)
    train_labels, test_labels = tf.dynamic_partition(all_labels, partitions, 2)

    # create input queues
    train_input_queue_image = tf.train.slice_input_producer(
        [train_images],
        shuffle=False)

    train_input_queue_label = tf.train.slice_input_producer(
        [train_labels],
        shuffle=False)

    # process path and string tensor into an image and a label
    file_content_train_data = tf.read_file(train_input_queue_image[0])
    train_image = tf.image.decode_jpeg(file_content_train_data, channels=3)
    train_image = tf.cast(train_image, dtype=np.float32)
    # train_image = train_image * 1 / 256.
    # print train_image.get_shape()

    file_content_train_label = tf.read_file(train_input_queue_label[0])
    train_label = tf.image.decode_png(file_content_train_label, channels=1, dtype=tf.uint16)
    train_label = tf.cast(train_label, dtype=np.float32)
    train_label = train_label * 100 / 65536

    # Training data argumentation #
    distortions = tf.random_uniform([6], 0, 1.0, dtype=tf.float32)

    # flip left and right transformation #
    value_flip = np.random.rand(1) * 100000
    value_flip = np.floor(value_flip)
    train_image = tf.image.random_flip_left_right(train_image, seed=value_flip)
    train_label = tf.image.random_flip_left_right(train_label, seed=value_flip)

    # scale rgb and d randomly [1, 1.2, 1.5] #
    def scale_transform(train_image, train_label, IMAGE_HEIGHT, IMAGE_WIDTH):
        randn = 1 + distortions[1]/2
        scale = tf.to_float(tf.to_int32(randn*10, name='ToInt32'), name='ToFloat')/10.
        new_height = tf.to_int32(IMAGE_HEIGHT * scale, name='ToInt32')
        new_width = tf.to_int32(IMAGE_WIDTH * scale, name='ToInt32')
        train_image_new = tf.image.resize_images(train_image, [new_height, new_width], 0)
        train_label_new = tf.image.resize_images(train_label, [new_height, new_width], 0)
        train_label_new = train_label_new / scale
        train_image = tf.image.resize_image_with_crop_or_pad(train_image_new, IMAGE_HEIGHT, IMAGE_WIDTH)
        train_label = tf.image.resize_image_with_crop_or_pad(train_label_new, IMAGE_HEIGHT, IMAGE_WIDTH)
        return train_image, train_label

    train_image, train_label = scale_transform(train_image, train_label, IMAGE_HEIGHT, IMAGE_WIDTH)

    # color transformation #
    color_factor = 0.8 + 0.4*distortions[1]
    train_image = train_image * color_factor

    # resize #
    train_image = tf.image.resize_images(train_image, [224, 160])
    train_label = tf.image.resize_images(train_label, [224, 160])

    train_image.set_shape([224, 160, 3])
    train_label.set_shape([224, 160, 1])


    images_batch, labels_batch = tf.train.shuffle_batch(
        [train_image, train_label],
        batch_size=8,
        capacity=4000,
        min_after_dequeue=1000)

#    images_batch = tf.expand_dims(images_batch, 0)
#    labels_batch = tf.expand_dims(labels_batch, 0)

    print "input pipeline ready"
    return images_batch, labels_batch