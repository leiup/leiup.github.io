
import numpy as np
import cv2

def show_image(pre_depth, train_image_aug1, train_label_aug1, batch_size):

    images = concate_func_16(train_image_aug1, batch_size)
    win_images1 = cv2.namedWindow('input_images', 0)
    cv2.imshow('input_images', images / 255)

    dep_ground = concate_func_16(train_label_aug1, batch_size)
    # win_images2 = cv2.namedWindow('groundtruth_depth', 0)
    # cv2.imshow('groundtruth_depth', dep_ground / 50)

    dep_pre = concate_func_16(pre_depth, batch_size)
    # win_images3 = cv2.namedWindow('prediction_depth', 0)
    # cv2.imshow('prediction_depth', dep_pre / 50)

    heatmap_layer = np.concatenate((dep_ground, dep_pre), 1)
    win_images4 = cv2.namedWindow('depth_cpmparison', 0)
    cv2.imshow('depth_cpmparison', heatmap_layer / 70)

    cv2.waitKey(1000)
    cv2.destroyWindow('all')

def concate_func(images):
    size_height = images.shape[1]
    size_width = images.shape[2]
    mask = np.zeros((size_height * 2, size_width * 2, 1))

    mask[0:size_height, 0:size_width, ...] = images[0, ...]
    mask[0:size_height, size_width:size_width*2, ...] = images[1, ...]
    mask[size_height:size_height*2, 0:size_width, ...] = images[2, ...]
    mask[size_height:size_height*2, size_width:size_width*2, ...] = images[3, ...]
    return mask

def concate_func_16(images, batch_size):
    size_scale_float = np.sqrt(batch_size)
    size_scale_height = size_scale_float.astype(np.int64)
    size_scale_width = batch_size / size_scale_height
    size_height = images.shape[1]
    size_width = images.shape[2]
    channel = images.shape[3]
    mask = np.zeros((size_height * size_scale_height, size_width * size_scale_width, channel))

    # mask[0:size_height, 0:size_width, ...] = images[0, ...]
    # mask[0:size_height, size_width:size_width*2, ...] = images[1, ...]
    # mask[0:size_height, size_width * 2:size_width * 3, ...] = images[2, ...]
    # mask[0:size_height, size_width * 3:size_width * 4, ...] = images[3, ...]
    #
    # mask[size_height:size_height * 2, 0:size_width, ...] = images[4, ...]
    # mask[size_height:size_height * 2, size_width:size_width*2, ...] = images[5, ...]
    # mask[size_height:size_height * 2, size_width * 2:size_width * 3, ...] = images[6, ...]
    # mask[size_height:size_height * 2, size_width * 3:size_width * 4, ...] = images[7, ...]
    #
    # mask[size_height * 2:size_height * 3, 0:size_width, ...] = images[8, ...]
    # mask[size_height * 2:size_height * 3, size_width:size_width*2, ...] = images[9, ...]
    # mask[size_height * 2:size_height * 3, size_width * 2:size_width * 3, ...] = images[10, ...]
    # mask[size_height * 2:size_height * 3, size_width * 3:size_width * 4, ...] = images[11, ...]
    #
    # mask[size_height * 3:size_height * 4, 0:size_width, ...] = images[12, ...]
    # mask[size_height * 3:size_height * 4, size_width:size_width*2, ...] = images[13, ...]
    # mask[size_height * 3:size_height * 4, size_width * 2:size_width * 3, ...] = images[14, ...]
    # mask[size_height * 3:size_height * 4, size_width * 3:size_width * 4, ...] = images[15, ...]

    for x in range(0, size_scale_height):
        for y in range(0, size_scale_width):
            mask[size_height * x:size_height * (x + 1), size_width * y:size_width * (y + 1), ...] = images[y + size_scale_width * x, ...]
    return mask

def inter_map(heatmap_layer, batch_size):
    heatmap_layer_0 = concate_func_16(np.expand_dims(heatmap_layer[..., 0], 3), batch_size)
    heatmap_layer_1 = concate_func_16(np.expand_dims(heatmap_layer[..., 1], 3), batch_size)
    heatmap_layer_2 = concate_func_16(np.expand_dims(heatmap_layer[..., 2], 3), batch_size)
    heatmap_layer = np.concatenate((heatmap_layer_0, heatmap_layer_1, heatmap_layer_2), 1)
    return heatmap_layer